// This is a custom exception class for handling invalid user input.

public class InvalidUserException extends Exception {
	private static final long serialVersionUID = 1L; // Unique ID for serialization and deserialization 
    // The constructor takes a string message as a parameter.
    public InvalidUserException(String message) {
    	//passed to the superclass constructor (Exception).
        super(message);
    }
}

// This is a custom exception class for handling invalid class operations.
class InvalidClassException extends Exception { // Unique ID for serialization and deserialization 
	private static final long serialVersionUID = 1L;
    public InvalidClassException(String message) {
        super(message);
    }
}
