import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

//This class represents a Gym Management System
//It manages members, staff, fitness classes, and equipment in a gym.
//It provides functionalities to register members and staff, schedule classes, manage equipment, generate reports and many more functionality
public class GymManagementSystem {
	// LinkedLists to store members, staff, fitness classes, and equipment
	//Generic used
	private LinkedList<Member> members;
	private LinkedList<Staff> staffs;
	private LinkedList<FitnessClass> fitnessClasses;
	private LinkedList<Equipment> equipmentInventory;
	private Thread saveThread;
	private volatile boolean shouldSave = true;
	// Default constructor that initializes each LinkedList
	public GymManagementSystem() {
		members = new LinkedList<>();
		staffs = new LinkedList<>();
		fitnessClasses = new LinkedList<>();
		equipmentInventory = new LinkedList<>();
		//multithreading
		saveThread = new Thread(() -> {
			while (shouldSave) {
				try {
					Thread.sleep(10000); // Sleep for 10 seconds
					saveData();
				} catch (InterruptedException e) {
					// Handle interruption if needed
					break; // Exit the loop if interrupted
				}
			}
		});
		saveThread.start(); // Start the saving thread
	}
	
	// Method to get list of members
	public LinkedList<Member>getMembers(){
			return members;
	}
	// Method to get list of Staffs
	public LinkedList<Staff>getStaffs(){
		return staffs;
	}
	// Method to get list of fitness Classes
	public LinkedList<FitnessClass> getFitnessClasses(){
	    return fitnessClasses;
	}
	// Method to get list of equipment in Inventory 
	public LinkedList<Equipment> getEquipmentInventory() {
	    return equipmentInventory;
	}
	
	// Method to register or add member to the system
	public void registerMember(Member member) throws InvalidUserException{
		// Check if a member with the same ID already exists
		for(Member existingMember : members) {
			if(existingMember.getMemberId().equals(member.getMemberId())) {
				throw new InvalidUserException("A member with this ID already exists");
			}
		}
		// Check if the contact number and email are empty
		if(member.getContactNumber().isBlank() || member.getEmail().isEmpty()) {
			throw new InvalidUserException("Contact number and email cannot be empty.");
		}
		// Add the member to the list
		members.add(member);
	}
	// Method to display member
	public void displayMembers(){
		if(members.isEmpty()) {
			System.out.println("\nNo members registered yet.\n");
		}else {
			System.out.println("\nRegistered Members:");
			for(Member member : members) {
				System.out.println("Member ID: "+member.getUserInfo());
			}
			System.out.println();
		}
	}
	// Method to remove Member from the system
	public Member removeMember(String memberId) {
	    // Iterate over the list of members
	    for (Member member : members) {
	        // If the member with the given ID is found, remove it from the list
	        if (member.getMemberId().equals(memberId)) {
	            members.remove(member);
	            return member; // Member found and removed
	        }
	    }
	    return null; // Member not found
	}
	// Method to add staff to the system
	public Staff registerStaff(Staff staff) throws InvalidUserException{
		// Check if a staff member with the same ID already exists
		for(Staff existingStaff : staffs) {
			if(existingStaff.getStaffId().equals(staff.getStaffId())) {
				throw new InvalidUserException("A staff member with this ID already exists");
			}
		}
		// Check if the contact number and email are empty
		if(staff.getContactNumber().isBlank() || staff.getEmail().isEmpty()) {
			throw new InvalidUserException("Contact number and email cannot be empty.");
		}
		// Add the staff member to the list
		staffs.add(staff);
		return staff;
	}
	// Method to display member
	public void displayStaff() {
	    int index = 1;
	    if(staffs.isEmpty()) {
	        System.out.println("\nNo Staff registered yet.\n");
	    } else {
	        System.out.println("\nRegistered Staff:");
	        for(Staff staff : staffs) {
	            System.out.println(index + ". Staff ID: " + staff.getUserInfo());
	            index++;
	        }
	        System.out.println();
	    }
	}
	// Method to remove Staff from the system
	public Staff removeStaff(String staffId) {
	    // Iterate over the list of staff
	    for (Staff staff : staffs) {
	        // If the staff with the given ID is found, remove it from the list
	        if (staff.getStaffId().equals(staffId)) {
	            staffs.remove(staff);
	            return staff; // Staff found and removed
	        }
	    }
	    return null; // Staff not found
	}
	// Method to add equipment to the system
	public boolean addEquipment(Equipment equipment) {
	    // Check if the equipment already exists in the inventory
	    for (Equipment existingEquipment : equipmentInventory) {
	        if (existingEquipment.getEquipName().equalsIgnoreCase(equipment.getEquipName())) {
	            System.out.println("\nEquipment already exists in the inventory.");
	            return false;
	        }
	    }
	    // Add the equipment to the inventory
	    equipmentInventory.add(equipment);
	    return true;
	}
	// Method to display Equipment inventory
	public void viewEquipmentInventory(){
		if(equipmentInventory.isEmpty()) {
			System.out.println("\nEquipment Inventory is Empty.\n");
		} else {
			System.out.println("\nEquipment Inventory:");
		    for(Equipment equipment : equipmentInventory) {
		    	System.out.println(equipment.toString());
		    }
		    System.out.println();
		}
	}

	//Method to Delete equipment 
	public boolean deleteEquipmentByName(String equipName) {
	    Iterator<Equipment> iterator = equipmentInventory.iterator();
	    while (iterator.hasNext()) {
	        Equipment equipment = iterator.next();
	        if (equipment.getEquipName().equalsIgnoreCase(equipName)) {
	            iterator.remove();
	            return true; // Equipment found and deleted
	        }
	    }
	    return false; // Equipment not found
	}


	// Method to schedule fitness class
	public void scheduleClass(FitnessClass newClass) throws InvalidClassException {
	    // Check if a class in the same room already exists at the same time
	    for(FitnessClass existingClass : fitnessClasses) {
	        if(existingClass.getRoomID().equals(newClass.getRoomID())) {
	            throw new InvalidClassException("A class in this room already exists at the same time.");
	        }
	    }
	    // Add the new class to the list after checking
	    fitnessClasses.add(newClass);
	}
	// Method to display fitness Classes
	public void displayAvailableClasses() {
		if(fitnessClasses == null || fitnessClasses.isEmpty()) {
			System.out.println("\nNo Fitness classes scheduled yet.\n");
		}else {
			System.out.println("\nScheduled Fitness Classes:");
			for(FitnessClass fitnessClass : fitnessClasses) {
				System.out.println(fitnessClass.toString());
			}
			System.out.println();
		}
	}
	// Method to update Member details
	public boolean updateMemberInformation(String memberId, String newContactNumber, String newEmail, String newMembershipType) throws InvalidUserException {
	    // Find the member with the given ID
	    for(Member member : members) {
	        if(member.getMemberId().equals(memberId)) {
	            // Update the contact number, email, and membership type if they are not blank
	            if(newContactNumber != null && !newContactNumber.isBlank()) {
	                member.setContactNumber(newContactNumber);
	            }
	            if(newEmail != null && !newEmail.isBlank()) {
	                member.setEmail(newEmail);
	            }
	            if(newMembershipType != null && !newMembershipType.isBlank()) {
	                member.setMembershipType(newMembershipType);
	            }
	            return true;
	        }
	    }
	    return false;
	}
	// Method to update Class details
	public boolean updateClass(String classId, String newRoomName, String newInstructorName, String newStartTime, String newEndTime, int newCapacity) throws InvalidUserException {
	    // Find the class with the given ID
	    for (FitnessClass fitnessClass : fitnessClasses) {
	        if (fitnessClass.getRoomID().equals(classId)) {
	            // Update the room name, instructor name, start time, end time, and capacity if they are not blank
	            if(newRoomName != null && !newRoomName.isBlank()) {
	                fitnessClass.setRoomName(newRoomName);
	                System.out.println("Room name updated successfully!");
	            }
	            if(newInstructorName != null && !newInstructorName.isBlank()) {
	                fitnessClass.setInstructorName(newInstructorName);
	                System.out.println("Instructor name updated successfully!");
	            }
	            if(newStartTime != null && !newStartTime.isBlank()) {
	                fitnessClass.setStartTime(newStartTime);
	                System.out.println("Start time updated successfully!");
	            }
	            if(newEndTime != null && !newEndTime.isBlank()) {
	                fitnessClass.setEndTime(newEndTime);
	                System.out.println("End time updated successfully!");
	            }
	            if(newCapacity > 0) {
	                fitnessClass.setCapacity(newCapacity);
	                System.out.println("Capacity updated successfully!");
	            }
	            return true;
	        }
	    }
	    return false;
	}


	// Method to Cancel a Class
	public void cancelClass(String classId) throws InvalidClassException {
		// Find the class with the given ID
		for (FitnessClass fitnessClass : fitnessClasses) {
			if (fitnessClass.getRoomID().equals(classId)) {
				// Remove the class from the list
				fitnessClasses.remove(fitnessClass);
				return;
			}
		}
		throw new InvalidClassException("\nClass with ID " + classId + " not found.");
	}
	// Method to saveData to a file 
	//      I/O Programming
	public void saveData() {
		//String filename = "gym_data.ser";
		new Thread(() -> {
			try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("gym_data.ser"))) {
			// Write the LinkedLists to the file
			oos.writeObject(members);
			oos.writeObject(staffs);
			oos.writeObject(fitnessClasses);
			oos.writeObject(equipmentInventory);
			
			//save the unique IDs
			oos.writeObject(Member.getNextUniqueId());
	        oos.writeObject(Staff.getNextUniqueId());
	        oos.writeObject(FitnessClass.getNextUniqueId());
			//System.out.println("\nData from " + filename + " Saved successfully.\n");
		} catch (IOException e) {
			System.out.println("Error saving data: " + e.getMessage());
		}
		}).start();

	}
	public void toggleAutoSave(boolean enableAutoSave) {
		shouldSave = enableAutoSave;
	}
	// Method to loadData from a file 
	@SuppressWarnings("unchecked")
	//  I/O Programming
	public void loadData() {
		//String filename = "gym_data.ser";
		new Thread(() -> {
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("gym_data.ser"))) {
			// Read the LinkedLists from the file
			members = (LinkedList<Member>) ois.readObject();
			staffs = (LinkedList<Staff>) ois.readObject();
			fitnessClasses = (LinkedList<FitnessClass>) ois.readObject();
			equipmentInventory = (LinkedList<Equipment>) ois.readObject();
			Member.setUniqueID((int) ois.readObject());
			Staff.setUniqueID((int) ois.readObject());
			FitnessClass.setUniqueID((int) ois.readObject());
			//System.out.println("\nData from " + filename + " loaded successfully.\n");
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Error loading data: " + e.getMessage());
		}
		}).start();
	}
	// Method to search classes
	public List<FitnessClass> searchClasses(String keyword) {
		// Filter the classes based on the keyword
		return fitnessClasses.stream()
				.filter(c -> c.getRoomName().toLowerCase().contains(keyword.toLowerCase()) ||
						c.getInstructorName().toLowerCase().contains(keyword.toLowerCase()))
				.collect(Collectors.toList());
	}
	// Method to search equipment 
	public List<Equipment> searchEquipment(String keyword) {
		// Filter the equipment based on the keyword
		return equipmentInventory.stream()
				.filter(e -> e.getEquipName().toLowerCase().contains(keyword.toLowerCase()) ||
						e.getEquipDescription().toLowerCase().contains(keyword.toLowerCase()))
				.collect(Collectors.toList());
	}
	// Method to generate a report
	public void generateReport(String reportType, String fileName) {
		try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
			// Generate a report based on the report type
			switch (reportType.toLowerCase()) {
				case "membership":
					writer.println("Membership Report");
					writer.println("------------------");
					for (Member member : members) {
						writer.println(member.getUserInfo());
		
					}
					System.out.println("\nLoading Report details from " + fileName);
					delayMessage(5000);
					printMembershipSummary();
					delayMessage(2000);
					System.out.println("\nReport generated successfully.");
					break;
				case "class":
					writer.println("Class Attendance Report");
					writer.println("------------------------");
					for (FitnessClass fitnessClass : fitnessClasses) {
						writer.println(fitnessClass.toString());
					}
					System.out.println("\nLoading Report details from " + fileName);
					delayMessage(5000);
					printClassSummary();
					delayMessage(2000);
					System.out.println("\nReport generated successfully.");
					break;
				case "equipment":
					writer.println("Equipment Inventory Report");
					writer.println("----------------------------");
					for (Equipment equipment : equipmentInventory) {
						writer.println(equipment.toString());
					}
					System.out.println("\nLoading Report details from " + fileName);
					delayMessage(5000);
					printEquipmentSummary();
					delayMessage(2000);
					System.out.println("\nReport generated successfully.");
					break;
				default:
					System.out.println("\nInvalid report type.");
					return;
			}
			 
		} catch (IOException e) {
			System.out.println("\nError generating report: " + e.getMessage());
		}
	}
	// Method to simulate loading or delayMessage
	private void delayMessage(int milliseconds) {
	    try {
	        Thread.sleep(milliseconds);
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }
	}
	// Method to display membership summary
	private void printMembershipSummary() {
	    int standardCount = 0;
	    int premiumCount = 0;

	    for (Member member : members) {
	        if (member.getMembershipType().equalsIgnoreCase("standard")) {
	            standardCount++;
	        } else if (member.getMembershipType().equalsIgnoreCase("premium")) {
	            premiumCount++;
	        }
	    }

	    System.out.println("\nDetails loading Please wait.............");
	    delayMessage(8000);

	    if (standardCount + premiumCount == 0) {
	        System.out.println("\nYou currently have no members.");
	    } else {
	        System.out.println("\nThere are currently " + (standardCount + premiumCount) + " member(s).");
	        System.out.println(standardCount + " are standard member(s) and " + premiumCount + " are premium member(s).");
	    }
	}
	// Method to read and display class summary from file
	private void printClassSummary() {
	    // Create HashMaps to store counts of instructors, rooms, and times
		//Generic used
	    Map<String, Integer> instructorCount = new HashMap<>();
	    Map<String, Integer> roomCount = new HashMap<>();
	    Map<String, Integer> timeCount = new HashMap<>();
	    
	    // Variable to store total capacity of all classes
	    int totalCapacity = 0;

	    // Iterate over each FitnessClass in fitnessClasses
	    for (FitnessClass fitnessClass : fitnessClasses) {
	        // Increment count of this instructor in instructorCount
	        instructorCount.put(fitnessClass.getInstructorName().toLowerCase(), instructorCount.getOrDefault(fitnessClass.getInstructorName().toLowerCase(), 0) + 1);
	        // Increment count of this room in roomCount
	        roomCount.put(fitnessClass.getRoomName().toLowerCase(), roomCount.getOrDefault(fitnessClass.getRoomName().toLowerCase(), 0) + 1);
	        // Increment count of this time slot in timeCount
	        timeCount.put(fitnessClass.getStartTime() + "-" + fitnessClass.getEndTime(), timeCount.getOrDefault(fitnessClass.getStartTime() + "-" + fitnessClass.getEndTime(), 0) + 1);
	        // Add this class's capacity to totalCapacity
	        totalCapacity += fitnessClass.getCapacity();
	    }

	    // Print loading message and delay for effect
	    System.out.println("\nDetails loading Please wait.............");
	    delayMessage(8000);

	    // If there are no classes, print a message saying so
	    if (fitnessClasses.size() == 0) {
	        System.out.println("\nThere is currently no Scheduled classes.");
	    } else {
	        // Otherwise, print the total number of classes
	        System.out.println("\nThere are currently " + fitnessClasses.size() + " classe(s).");
	        // Print the average class capacity
	        System.out.println("The average scheduleClass capacity: " + ((double)totalCapacity / fitnessClasses.size()));
	        // Print the counts of classes by instructor, room, and time
	        System.out.println("Classes by Instructor: " + instructorCount);
	        System.out.println("Classes by Room: " + roomCount);
	        System.out.println("Classes by Time: " + timeCount);
	    }
	}
	// Method to read and display equipment summary from file
	private void printEquipmentSummary() {
	    // Create a HashMap to store counts of equipment
	    Map<String, Integer> equipmentCount = new HashMap<>();
	    int lowStockThreshold = 5; //threshold value
	    int highStockThreshold = 10; //threshold value
	    List<String> lowStockEquipment = new ArrayList<>();
	    List<String> highStockEquipment = new ArrayList<>();

	    // Iterate over each Equipment in equipmentInventory
	    for (Equipment equipment : equipmentInventory) {
	        // Increment count of this equipment in equipmentCount
	        equipmentCount.put(equipment.getEquipName().toLowerCase(), equipmentCount.getOrDefault(equipment.getEquipName().toLowerCase(), 0) + 1);
	        
	        // Check if the equipment quantity is less than or equal to the low stock threshold
	        if (equipment.getQuantity() <= lowStockThreshold) {
	            lowStockEquipment.add(equipment.getEquipName() + " qty=" + equipment.getQuantity());
	        }
	        
	        // Check if the equipment quantity is greater than or equal to the high stock threshold
	        if (equipment.getQuantity() >= highStockThreshold) {
	            highStockEquipment.add(equipment.getEquipName() + " qty=" + equipment.getQuantity());
	        }
	    }

	    // Print loading message and delay for effect
	    System.out.println("\nDetails loading Please wait.............");
	    delayMessage(8000);

	    // If there is no equipment, print a message saying so
	    if (equipmentInventory.size() == 0) {
	        System.out.println("\nThere is currently no equipment in Inventory.");
	    } else {
	        // Otherwise, print the total number of equipment
	        System.out.println("\nThere are  currently " + equipmentInventory.size() + " piece(s) of equipment.");
	        // Print the counts of equipment
	        System.out.println("Equipment: " + equipmentCount);
	        // Print the names of equipment that are low in stock
	        if (!lowStockEquipment.isEmpty()) {
	            System.out.println("The following equipment(s) are low in stock: " + String.join(", ", lowStockEquipment));
	        }
	        // Print the names of equipment that are high in stock
	        if (!highStockEquipment.isEmpty()) {
	            System.out.println("The following equipment(s) are high in stock: " + String.join(", ", highStockEquipment));
	        }
	    }
	}


}
