// The Equipment class represents a piece of equipment in our system.
// It implements the Serializable interface to allow Equipment objects to be converted to a byte stream


import java.io.Serializable;
public class Equipment implements Serializable {
	private String equip_name;
	private int quantity;
	private String equip_description;
	//private String category;
	//private String condition;
	//private Date purchaseDate;
	private static final long serialVersionUID = 1L;
	
	// Constructor that initializes the equipment name, quantity, and description with the provided values
	 public Equipment(String equip_name, int quantity, String equip_description) {
	        this.equip_name = equip_name;
	        this.quantity = quantity;
	        this.equip_description = equip_description;
	 }
	// Getter and setter for retrieving and updating equipment deals.
	 public String getEquipName() {
		 return this.equip_name;
	 }
	 public void setEquipName(String equip_name) {
		this.equip_name = equip_name;
	 }
	 public int getQuantity() {
		 return this.quantity;
	 }
	 public void setQuantity(int quantity) {
		  this.quantity = quantity;
	 }
	 public String getEquipDescription() {
		 return this.equip_description;
	 }
	 public void setEquipDescription(String equip_description) {
		 this.equip_description = equip_description;
	 }
	// Overridden toString method from Object class to return detailed equipment information
	 @Override
	 public String toString() {
		 return "Equipment Name: " + equip_name + ", Quantity: " + quantity +
	               ", Description: " + equip_description;
	 }
}
