
public class Main {

    public static void main(String[] args) throws InvalidUserException{
        GymManagementSystem gymManagementSystem = new GymManagementSystem();
        GymInterface gymInterface = new GymInterface(gymManagementSystem);;


		// Add atLeast staff member before starting the interface
		Staff staff = new Staff("Admin", "1234567890", "SysAdmin", "admin@example.com", "admin");
		gymManagementSystem.registerStaff(staff);
		System.out.println("Registered staff with ID: " + staff.getStaffId());; // get OR see registered staff id for login purpose;

        try {
            gymInterface.start();
        } finally {
            gymManagementSystem.saveData();
        }

    }

}
