
/*
 *  The FitnessClass implements Serializable interface which allows it to be converted into a byte stream
 */
import java.io.Serializable;

class FitnessClass implements Serializable {
	//static variable to generate unique IDs for each class
	private static int uniqueID = 0;
	 private static final long serialVersionUID = 1L;// Unique ID for serialization and deserialization of the Fitness class
	// Instance variables for the class
	private int capacity; // account for maximum number of people in a room 
	private String roomID; 
	private String roomName;
	private String instructorName;
	private String startTime; // start time of class
	private String endTime; //end time of class
	
	// Default constructor. Initializes all instance variables to their default values and assigns a unique ID to the class
	public FitnessClass() {
		this.roomID = "CLS" + String.format("%04d", getNextUniqueId());
		this.capacity = 0;
		this.roomName = "";
		this.instructorName = "";
		this.startTime = "";
		this.endTime = "";
	}
	// Parameterized constructor. Initializes all instance variables to the values passed as parameters and assigns a unique ID to the class
	public FitnessClass(String roomName, String instructorName, String startTime, String endTime, int capacity) {
		this.roomID = "CLS" + String.format("%04d", getNextUniqueId());
		this.roomName = roomName;
		this.instructorName = instructorName;
		this.startTime = startTime;
		this.endTime = endTime;
		this.capacity = capacity;
	}
	// Getter and setter methods for all instance variables ensuring retrieval  and updating of private fields
	public String getRoomID() {
		return this.roomID;
	}
	public String getRoomName() {
		return this.roomName;
		
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getInstructorName() {
		return this.instructorName;
		
	}
	public void setInstructorName(String instructorName) {
		this.instructorName = instructorName;
	}
	public String getStartTime() {
		return this.startTime;
		
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return this.endTime;
		
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public int getCapacity() {
		return this.capacity;
	}
	public void setCapacity(int capacity) throws InvalidUserException {
		if(capacity <= 0 || capacity > 100 ) {
			throw new InvalidUserException("Capacity must be betwwen 1 and 100");
		}else {
			this.capacity = capacity;
		}
	}
	
	// Synchronized method to ensure thread safety when generating unique IDs
    public synchronized static int getNextUniqueId() {
        return uniqueID++;
    }
    public static synchronized void setUniqueID(int uniqueID) {
    	FitnessClass.uniqueID = uniqueID; 
	}
	
 //toString method to provide a string representation of the class
	@Override
	public String toString() {
		return 
				"Class ID: " + this.roomID + ", " +
		           "Room Name: " + this.roomName + ", " +
		           "Instructor Name: " + this.instructorName + ", " +
		           "Start Time: " + this.startTime + ", " +
		           "End Time: " + this.endTime + ", " +
		           "Capacity: " + this.capacity;
	}
}
