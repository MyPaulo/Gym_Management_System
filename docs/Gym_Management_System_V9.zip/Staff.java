
import java.io.Serializable;
//The Staff class represents a staff member in our gym management system.
//It extends the User superclass, inheriting its properties and methods.
//Each Staff object represents a unique staff member in the system
public class Staff extends User implements Serializable{
    
	//static variable uniqueID to generate a unique ID for each Staff.
    private static int uniqueID = 0;
    private static final long serialVersionUID = 1L;// Unique ID for serialization and deserialization of the Staff
    private String role;
    private String password;
    
    // Default constructor,
    public Staff() {
    	super("STF" + String.format("%04d", ++uniqueID), "Staff-class");
        this.role = " ";
    }
    
    // Constructor with parameters and calls to superclass constructor with a generated ID and given name,
    public Staff(String name, String contactNumber, String role,String staffEmail, String password) throws InvalidUserException {
    	super("STF" + String.format("%04d", uniqueID++), name);
        setContactNumber(contactNumber);
        setEmail(staffEmail);
        this.role = role;
        this.password = password;
    }
    
    // Getter  and setters for the staff 
    public String getStaffId() {
        return super.getId();
    }
    
    //getName method from the superclass.
    public String getName() {
        return super.getName();
    }
    
    // setName method from the superclass.
    public void setName(String name) {
        super.setName(name);
    }
    
    public String getRole() {
        return this.role;
    }
    public String getPassword() {
    	return this.password;
    }
    public void setPassword(String password) {
    	this.password = password;
    }
    public void setRole(String role) {
        this.role = role;
    }
 // Synchronized method to ensure thread safety when generating unique IDs
 	 public synchronized static int getNextUniqueId() {
 		 return uniqueID++;
 	 }
 	public static synchronized void setUniqueID(int uniqueID) {
	    Staff.uniqueID = uniqueID; 
	}
    @Override
    public String getUserInfo() {
        return getId() + ", Name: " + getName() +
               ", Role: " + role +
               ", Contact Number: " + getContactNumber() +
               ", Email: " + getEmail();
    }
}