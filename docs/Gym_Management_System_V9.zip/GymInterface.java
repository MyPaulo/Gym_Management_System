
/* this class will be used  to handle the Command Line Interface
	for GYM Management System, contains menus, user input and a call
	to appropriate method in GymManagementSystem class
*/

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


public class GymInterface {
	private GymManagementSystem  gymManagementSystem;//GymManagementSystem object to perform the backend operations
	private Scanner scanner;//Scanner object will used to read the user's input
	// Default constructor which  initializes the GymManagementSystem and Scanner objects
	public GymInterface(GymManagementSystem gymManagementSystem) {
		this.gymManagementSystem = gymManagementSystem;
		scanner = new Scanner(System.in);
	}
	//Method to check for authenticated Staffs via login
	public Staff login() throws InvalidUserException {
		System.out.print("Enter Staff ID: ");
        String staffId = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        for(Staff staff : gymManagementSystem.getStaffs()) {
        	if(staff.getStaffId().equals(staffId) && staff.getPassword().equals(password)) {
        		return staff;
        	}
        }
        throw new InvalidUserException("Invalid staff ID or password.");
	}
	// Method to display the main menu
		private void displayMainMenu() {
			System.out.println("Welcome to the Gym Management System!");
			System.out.println("-------------------------------------");
			System.out.println("1. Login");
			System.out.println("2. Manage Staff");
	        System.out.println("3. Register New Member");
	        System.out.println("4. Update Member Information");
	        System.out.println("5. Display Member List");
	        System.out.println("6. Remove Member");
	        System.out.println("7. Manage Fitness Classes");
	        System.out.println("8. Display Available Classes");
	        System.out.println("9. Manage Equipment");
	        System.out.println("10. View Equipment Inventory");
	        System.out.println("11. Generate Reports");
	        System.out.println("12. Logout");
			System.out.println("13. Toggle Auto-Save");
			System.out.println("0. Exit");
	        System.out.print("\nPlease select an option (0-13): ");
		}
		
	//start method begins the user interaction loop
	public void start() throws InvalidUserException{
		// Load data at the start
		gymManagementSystem.loadData();
		Staff loggedInStaff = null;
		boolean logged = false;
		while(true) {
			try {
				displayMainMenu();
				int choice = scanner.nextInt(); // get user choice
				scanner.nextLine(); // consume newline
				switch(choice) { // call appropriate method base on user choice
					case 1:
						if(!logged) {// Check if not logged in
							try {
								loggedInStaff = login();// Require login to manage staff
								logged = true;
								System.out.println("\n" + "logged in successfully, Welcome: " + loggedInStaff.getName());
								System.out.println();
								//gymManagementSystem.saveData(); 
							}catch(InvalidUserException  e) {
								System.out.println("\n" + e.getMessage() + "\n");
							}
						}else {
							System.out.println("\nYou are already logged in.\n");
						}
						break;
					case 2:
						if(logged) {
							manageStaff();  // If already logged in, directly manage staff
							gymManagementSystem.saveData();
						}else {
							System.out.println("\nYou must be logged in as staff to manage staff.\n");
						}
						break;
					case 3:
						if(loggedInStaff != null) {
							registerNewMember();
							gymManagementSystem.saveData(); // Save data after registering a new member
						}else {
							System.out.println("\nYou must be logged in as staff to register a new member.\n");
						}
						break;
					case 4:
						if (loggedInStaff != null) {
	                        updateMemberInformation();
	                        gymManagementSystem.saveData(); // Save data after updating member details
	                    } else {
	                        System.out.println("\nYou must be logged in as staff to update member information.\n");
	                    }
	                    break;
					case 5:
						gymManagementSystem.displayMembers(); //doesn't required login 
						break;
					case 6:
						if(loggedInStaff != null) {
							removeMember();  //If logged in successfully, manage staff
							gymManagementSystem.saveData(); // Save data after removing a  member
						}else {
							System.out.println("\nYou must be logged in as staff to remove a member.\n");
						}
						break;
					case 7:
						if (loggedInStaff != null) {
	                        manageFitnessClasses(); //If logged in successfully, manage Fitness class
	                    } else {
	                        System.out.println("\nYou must be logged in as staff to manage fitness classes.\n");
	                    }
	                    break;
					case 8:
	                    gymManagementSystem.displayAvailableClasses(); //doesn't required login 
	                    break;
					case 9:
						if (loggedInStaff != null) {
	                        manageEquipment();
	                    } else {
	                        System.out.println("\nYou must be logged in as staff to manage equipment.\n");
	                    }
	                    break;
					case 10:
						gymManagementSystem.viewEquipmentInventory(); //doesn't required login 
						break;
					case 11:
						if (loggedInStaff != null) {
	                        generateReports();
	                    } else {
	                        System.out.println("\nYou must be logged in as staff to generate reports.\n");
	                    }
						break;
					case 12:
						if(logged) {
							String name = loggedInStaff.getName(); //save the logged in staff before logging out
							loggedInStaff  = null; // Logout the current staff
							logged = false;
							System.out.println("\nLogged out successfully. GoodBye: "+ name + "\n");
						}else {
							System.out.println("\nYou are not currently logged in.\n");
						}
						break;
					case 13:
						toggleAutoSave();
						break;
					case 0:
						// Handle "Exit" and save to file to be implement later
						scanner.close();
						gymManagementSystem.saveData(); // Save data on exit
						gymManagementSystem.toggleAutoSave(false); // Stop auto-saving before exit
						gymManagementSystem.saveData();  // Perform a final save before closing
						System.out.println("\nThanks for using  Gym Management System. exiting........");
						System.exit(0);
					default:
						System.out.println("\nInvalid choice. Please enter a number between 0 and 12.\n");
				}
				
			}catch(InputMismatchException input) {
				System.out.println("\nInvalid input. Please enter a number.\n");
				scanner.nextLine(); // clear invalid input
			}
		}
	}
	private void toggleAutoSave() {
		int autoSaveChoice = 0;
		while (true) {
			try {
				System.out.println("\nAuto-Save Options:");
				System.out.println("1. Enable Auto-Save");
				System.out.println("2. Disable Auto-Save");
				System.out.println("3. Return to Main Menu");
				System.out.print("Enter your choice (1-3): ");
				autoSaveChoice = scanner.nextInt();
				scanner.nextLine(); // Consume the newline character

				if (autoSaveChoice >= 1 && autoSaveChoice <= 3) {
					break; // Valid choice, exit the loop
				} else {
					System.out.println("\nInvalid choice. Please enter 1, 2, or 3.\n");
				}
			} catch (InputMismatchException e) {
				System.out.println("\nInvalid input. Please enter a number.\n");
				scanner.nextLine(); // Clear invalid input
			}
		}

		switch (autoSaveChoice) {
			case 1:
				gymManagementSystem.toggleAutoSave(true);
				System.out.println("\nAuto-save enabled.\n");
				break;
			case 2:
				gymManagementSystem.toggleAutoSave(false);
				System.out.println("\nAuto-save disabled.\n");
				break;
			case 3:
				System.out.println("\nReturning to Main Menu.\n");
				return;
		}
	}
	// Method to manage fitness classes
	private void manageStaff() throws InvalidUserException{
		while(true) {
			System.out.println("\nManage Staff");
	        System.out.println("------------");
			System.out.println("1. Add Staff");
	        System.out.println("2. Update Staff Information");
	        System.out.println("3. Display Staff List");
	        System.out.println("4. Remove Staff");
	        System.out.println("5. Return to Main Menu");
	        System.out.print("\nPlease select an option (1-5): ");
			    
		    try {
		    	int choice  = scanner.nextInt();
		    	scanner.nextLine();
		    	switch(choice) {
		    		case 1:
		    			addStaff();
		    			break;
		    		case 2:
		    			updateStaffInformation();
		    			break;
		    		case 3:
		    			gymManagementSystem.displayStaff();
		    			break;
		    		case 4:
		    			removeStaff();
		    			gymManagementSystem.saveData(); // Save data after removing a  Staff
		    			break;
		    		case 5:
		    			System.out.println();
		    			 return; 
		    		default:
		    			System.out.println("\nInvalid choice. Please enter a number between 1 and 5.");
		    	}
		    }catch(InputMismatchException input) {
		    	System.out.println("\nInvalid input. Please enter a number.");
				scanner.nextLine(); // clear invalid input
		    }
		}
	}
	// Method to register a new Staff
	private void addStaff() {
		String staff_name = validateInput(scanner, "Enter Staff's Name: ", "Invalid name. Please enter a valid name.", "^[a-zA-Z ]+$");
		String staff_role = validateInput(scanner, "Enter Staff's Role: ", "Invalid role. Please enter a valid role.", "^[a-zA-Z ]+$");
		System.out.print("Enter Password: ");
	    String password = scanner.nextLine();
		System.out.print("Enter Contact Number: ");
		String contactNumber = scanner.nextLine();
		System.out.print("Enter Email: ");
		String staff_email = scanner.nextLine();
		
		StringBuilder errorMessage  = new StringBuilder();
		boolean isValid = true;
		if (!User.isValidPhoneNumber(contactNumber)) { // Using super class User  method to validate input 
	        errorMessage.append("Invalid phone number format. Phone number must be 10 digits. Example: 6142970448\n");
	        isValid = false;
	    }
		if (!User.isValidEmail(staff_email)) { // Using super class User  method to validate input 
	        errorMessage.append("Invalid email format. Email must match the pattern '^[A-Za-z0-9+_.-]+@(.+)$'. Example: test@gmail.com\n");
	        isValid = false;
		}
	    if (!isValid) {
	    	System.out.println("\nError registering member: " + errorMessage.toString());
	    	return;
	     }   
	    
		try {
			//Create a Staff Object with specified attributes
			Staff newStaff = new Staff(staff_name, contactNumber, staff_role, staff_email,password);
			gymManagementSystem.registerStaff(newStaff);
			gymManagementSystem.saveData(); // Save data after registering a new member
			System.out.println("\nStaff registered successfully Staff ID: " + newStaff.getUserInfo()  +  "\n");
		}catch(InvalidUserException error) {
			System.out.println("\nError registering staff: " + error.getMessage()+"\n");
			//error.printStackTrace();
		}
	}
	// Method to register a new member
	private void registerNewMember(){
		String name = validateInput(scanner, "Enter Member's Name: ", "Invalid name. Please enter a valid name.", "^[a-zA-Z ]+$");
		String membershipType = validateInput(scanner, "Enter Membership Type (Standard, Premium): ", "Invalid membership type. Please enter either 'Standard' or 'Premium'.", "^(?i)(Standard|Premium)$");
		System.out.print("Enter Contact Number: ");
		String contactNumber = scanner.nextLine();
		System.out.print("Enter Email: ");
		String email = scanner.nextLine();
		
		StringBuilder errorMessage  = new StringBuilder();
		boolean isValid = true;
		if (!User.isValidPhoneNumber(contactNumber)) { // Using super class User  method to validate input 
	        errorMessage.append("Invalid phone number format. Phone number must be 10 digits. Example: 6142970448\n");
	        isValid = false;
	    }
		if (!User.isValidEmail(email)) { // Using super class User  method to validate input 
	        errorMessage.append("Invalid email format. Email must match the pattern '^[A-Za-z0-9+_.-]+@(.+)$'. Example: test@gmail.com\n");
	        isValid = false;
		}
	    if (!isValid) {
	    	System.out.println("\nError registering member: " + errorMessage.toString());
	    	return;
	     }   
	    
		try {
			//Create a Member Object with specified attributes
			Member newMember = new Member(name, membershipType, contactNumber, email);
			gymManagementSystem.registerMember(newMember);
			gymManagementSystem.saveData(); // Save data after registering a new member
			System.out.println("\nMember registered successfully! Member ID: " + newMember.getUserInfo()  +  "\n");
		}catch(InvalidUserException error) {
			System.out.println("\nError registering member: " + error.getMessage()+"\n");
			//error.printStackTrace();
		}
	}
	//Method to Remove Staff  From the system
	public void removeStaff() {
	    System.out.print("Enter Staff ID to Remove: ");
	    String staffId = scanner.nextLine();
	    Staff removedStaff = gymManagementSystem.removeStaff(staffId);
	    if (removedStaff != null) {
	        System.out.println("\nStaff removed successfully. Removed details: " + removedStaff.getUserInfo() + "\n");
	    } else {
	        System.out.println("\nError: Staff with Id: " + staffId + " not found.\n");
	    }
	}
	//Method to Remove Member  From the system
	public void removeMember() {
	    System.out.print("Enter Member ID to Remove: ");
	    String memberId = scanner.nextLine();
	    Member removedMember = gymManagementSystem.removeMember(memberId);
	    if (removedMember != null) {
	        System.out.println("\nMember removed successfully. Removed details: " + removedMember.getUserInfo() + "\n");
	    } else {
	        System.out.println("\nError: Member with Id: " + memberId + " not found.\n");
	    }
	}

	//Method to add equipment  to the system
	private void addEquipment() {
		String equip_name = validateInput(scanner, "Enter Equipment Name: ", "Invalid name. Please enter a valid name.", "^[a-zA-Z ]+$");
		int quantity = -1;
		while(quantity < 0 || quantity > 100) {
			String quantitys = validateInput(scanner, "Enter Quanity: ", "Quanity should be a positive integer", "\\d+");//\\d represents a digit (a character in the range [0-9])
			quantity = Integer.parseInt(quantitys);
			if(quantity < 0 || quantity > 100) {
				System.out.println("Invalid Quantity. Please enter a number between 0 and 100.");
			}
		}
	    System.out.print("Enter Equipment Description: ");
	    String equip_description = scanner.nextLine();
	    Equipment newEquipment = new Equipment(equip_name, quantity, equip_description);
	    boolean isAdded = gymManagementSystem.addEquipment(newEquipment);
	    gymManagementSystem.saveData(); // Save data after adding a new equipment
	    if(isAdded) {
	    	System.out.println("\nEquipment added successfully: "+newEquipment.toString() +"\n");
	    }
	}
	// Method to manage fitness classes
	private void manageFitnessClasses() throws InvalidUserException{
	    while(true) {
	    	System.out.println("\nManage Fitness Classes");
		    System.out.println("----------------------");
		    System.out.println("1. Schedule a new class");
		    System.out.println("2. Update an existing class");
		    System.out.println("3. Search a class");
		    System.out.println("4. Cancel a class");
		    System.out.println("5. Return to Main Menu");
		    System.out.print("\nPlease select an option (1-5): ");
		    
	    	try {
	    		int choice  = scanner.nextInt();
	    		 scanner.nextLine();
	    		switch(choice) {
	    			case 1:
	    				scheduleNewClass();
	    				break;
	    			case 2:
	    				updateExistingClass();
	    				break;
	    			case 3:
	    				searchClass();
	    				break;
	    			case 4:
	    				cancelClass();
	    				break;
	    			case 5:
	    				System.out.println();
	    				 return;
	    				 
	    			default:
	    				System.out.println("\nInvalid choice. Please enter a number between 1 and 5.");
	    		}
	    	}catch(InputMismatchException input) {
	    		System.out.println("\nInvalid input. Please enter a number.");
				scanner.nextLine(); // clear invalid input
	    	}
	    }
	}
	// Method manage Equipment
		private void manageEquipment(){
		    while(true) {
		    	System.out.println("\nManage Equipment Invetory");
			    System.out.println("----------------------");
			    System.out.println("1. Add Equipment");
			    System.out.println("2. Update Equipment");
			    System.out.println("3. Search Eequipment");
			    System.out.println("4. Delete Equipment");
			    System.out.println("5. Return to Main Menu");
			    System.out.print("\nPlease select an option (1-5): ");
			    
		    	try {
		    		int choice  = scanner.nextInt();
		    		 scanner.nextLine();
		    		switch(choice) {
		    			case 1:
		    				addEquipment();
		    				gymManagementSystem.saveData(); // Save data after adding a new equipment
		    				break;
		    			case 2:
		    				updateExistingEquipment();
		    				break;
		    			case 3:
		    				searchEquipment();
		    				break;
		    			case 4:
		    				deleteEquipment();
		    				gymManagementSystem.saveData();
		    				break;
		    			case 5:
		    				System.out.println();
		    				 return;
		    				 
		    			default:
		    				System.out.println("\nInvalid choice. Please enter a number between 1 and 5.");
		    		}
		    	}catch(InputMismatchException input) {
		    		System.out.println("\nInvalid input. Please enter a number.");
					scanner.nextLine(); // clear invalid input
		    	}
		    }
		}
		
	//Method to generate report 
	private void generateReports(){
		//scanner.nextLine();
		while(true) {
			System.out.println("\nGenerate Reports");
			System.out.println("1. Membership Report");
			System.out.println("2. Class Attendance Report");
			System.out.println("3. Equipment Inventory Report");
			System.out.println("4. Return to Main Menu");
			System.out.print("\nSelect report type (1-4): ");
							    
			try {
				int choice  = scanner.nextInt();
				scanner.nextLine();
				String reportType;
				switch (choice) {
					case 1:
						reportType = "membership";
						break;
					case 2:
						reportType = "class";
						break;
					case 3:
						reportType = "equipment";
						break;
					case 4:
				    	System.out.println();
				    	return;
				    default:
				    	System.out.println("\nInvalid choice. Please enter a number between 1 and 4.\n");
				    	return;
				}
				System.out.print("Enter filename for the report: ");
				String fileName = scanner.nextLine();
				gymManagementSystem.generateReport(reportType, fileName);
			}catch(InputMismatchException input) {
			System.out.println("\nInvalid input. Please enter a number.");
			scanner.nextLine(); // clear invalid input
			}
		}
	}
	//method to schedule a new class
	private void scheduleNewClass() {
		// Ask the user for  details of the new class
		String roomName =  validateInput(scanner, "Enter Room Name: ", "Invalid name. Please enter a valid name.", "^[a-zA-Z0-9- ]+$");
		String instructorName = validateInput(scanner, "Enter Instructor Name: ", "Invalid name. Please enter a valid name.", "^[a-zA-Z ]+$");
		String startTime = validateInput(scanner, "Enter Start Time (HH:MM AM/PM): ", "Invalid time. Please enter a valid time.", "^(1[0-2]|0?[1-9]):[0-5][0-9] (AM|PM)$");
		String endTime = validateInput(scanner, "Enter End Time (HH:MM AM/PM): ", "Invalid time. Please enter a valid time.", "^(1[0-2]|0?[1-9]):[0-5][0-9] (AM|PM)$");
		 /* ^(1[0-2]|0?[1-9]):[0-5][0-9] (AM|PM)$
		 * explanation  ^ means beginning of line and time string must start after this symbol
		 * a group that matches either 1[0-2] or 0?[1-9]
		 * 1[0-2] matches any hour from 10 to 12
		 * 0?[1-9] matches any hour from 01 to 09, with the leading 0 being optional
		 * : colon separate hours and minutes from time string
		 * [0-5][0-9]: This matches any number from 00 to 59, and represents the minutes
		 * matches either “AM” or “PM”
		 * $ symbol marks the end of the line
		 */
	    //Validate capacity
		int capacity = -1; // Initialize to  invalid
	    while(capacity <= 0 || capacity > 100) {
	    	try {
	    		System.out.print("Enter Capacity: ");
		        capacity = scanner.nextInt();
		        scanner.nextLine();
		        if(capacity <=0 || capacity > 100) {
		        	System.out.println("Invalid input. Capacity must be between 1 and 100. Please try again.");
		        	capacity = -1;
		        }
	    	}catch(InputMismatchException  input) {
	    		System.out.println("Invalid input. Please enter a number.");
	            scanner.nextLine();
	    	}
	    }
	    
	 // Create a new FitnessClass object
	    FitnessClass  newRoom  = new FitnessClass(roomName, instructorName, startTime, endTime, capacity);
	 // Schedule the new class
	    try {
	    	gymManagementSystem.scheduleClass(newRoom);
	    	gymManagementSystem.saveData(); // Save data after registering a new class
	    	System.out.println("\nClass scheduled successfully: " + newRoom.toString() + "\n");
	    }catch(InvalidClassException error) {
	    	System.out.println("\nError scheduling class: " + error.getMessage() + "\n");
	    }
	}
	//Method to update Exiting class
	private void updateExistingClass() throws InvalidUserException{
	    System.out.print("Enter Class ID to Update: ");
	    String classId = scanner.nextLine();
	    
	    // Find the class with the given ID
	    for(FitnessClass fitnessClass : gymManagementSystem.getFitnessClasses()) {
	        if(fitnessClass.getRoomID().equals(classId)) {
	            // Display current details
	            System.out.println("\nCurrent Details - Room Name: " + fitnessClass.getRoomName() + ", Instructor Name: " + fitnessClass.getInstructorName() + ", Start Time: " + fitnessClass.getStartTime() + ", End Time: " + fitnessClass.getEndTime() + ", Capacity: " + fitnessClass.getCapacity());
	            
	            System.out.print("\nNew Room Name (press enter to skip): ");
	            String newRoomName = scanner.nextLine();
	            if(!newRoomName.isBlank()) {
	                fitnessClass.setRoomName(newRoomName);
	                System.out.println("Room name updated successfully!");
	            }
	            System.out.print("\nNew Instructor Name (press enter to skip): ");
	            String newInstructorName = scanner.nextLine();
	            if(!newInstructorName.isBlank()) {
	                fitnessClass.setInstructorName(newInstructorName);
	                System.out.println("Instructor name updated successfully!");
	            }
	            String startTime = validateInput(scanner, "\nStartTime  Time(HH:MM AM/PM): ", "Invalid time. Please enter a valid time.", "^(1[0-2]|0?[1-9]):[0-5][0-9] (AM|PM)$");
	            //String newStartTime = scanner.nextLine();
	            if(!startTime.isBlank()) {
	                if(startTime != null) {
	                    fitnessClass.setStartTime(startTime);
	                    System.out.println("Start time updated successfully!");
	                }
	            }
	            String endTime = validateInput(scanner, "\nEndTime  Time(HH:MM AM/PM): ", "Invalid time. Please enter a valid time.", "^(1[0-2]|0?[1-9]):[0-5][0-9] (AM|PM)$");
	            if(!endTime.isBlank()) {
	                if(endTime != null) {
	                    fitnessClass.setStartTime(endTime);
	                    System.out.println("endTime  updated successfully!");
	                }
	            }
	            System.out.print("\nNew Capacity (press enter to skip): ");
	            String newCapacityStr = scanner.nextLine();
	            if(!newCapacityStr.isBlank()) {
	                int newCapacity = -1; // Initialize to invalid
	                while(newCapacity <= 0 || newCapacity > 100) {
	                    try {
	                        newCapacity = Integer.parseInt(newCapacityStr);
	                        if(newCapacity <= 0 || newCapacity > 100) {
	                            System.out.println("Invalid input. Capacity must be between 1 and 100. Please try again.");
	                            System.out.print("\nNew Capacity (press enter to skip): ");
	                            newCapacityStr = scanner.nextLine();
	                        } else {
	                            fitnessClass.setCapacity(newCapacity);
	                            System.out.println("Capacity updated successfully!");
	                        }
	                    } catch(NumberFormatException e) {
	                        System.out.println("Invalid input. Please enter a number.");
	                        System.out.print("\nNew Capacity (press enter to skip): ");
	                        newCapacityStr = scanner.nextLine();
	                    }
	                }
	            }
	            gymManagementSystem.saveData(); // Save data after updating a class
	            System.out.println("\nClass updated successfully.");
	            return; // Return after updating the class information
	        }
	    }
	    System.out.println("\nError: Class with Id: "+classId+" not found.\n");
	}
	// Method to update existing equipments
	private void updateExistingEquipment() {
	    System.out.print("Enter Equipment Name to Update: ");
	    String equipName = scanner.nextLine();

	    // Find the equipment with the given name
	    for (Equipment existingEquipment : gymManagementSystem.getEquipmentInventory()) {
	        if (existingEquipment.getEquipName().equalsIgnoreCase(equipName)) {
	            // Display current details
	            System.out.println("\nCurrent Details - Equipment Name: " + existingEquipment.getEquipName() + ", Quantity: " + existingEquipment.getQuantity() + ", Description: " + existingEquipment.getEquipDescription());
	            String newEquipName =  validateInput(scanner, "\nNew Equipment Name: ", "Invalid name. Please enter a valid name.", "^[a-zA-Z ]+$");
	            if(!newEquipName.isBlank()) {
	                existingEquipment.setEquipName(newEquipName);
	                System.out.println("Equipment name updated successfully!");
	            }

	            System.out.print("\nNew Quantity (press enter to skip): ");
	            String newQuantityStr = scanner.nextLine();
	            if(!newQuantityStr.isBlank()) {
	                try {
	                    int newQuantity = Integer.parseInt(newQuantityStr);
	                    if(newQuantity > 0 && newQuantity <= 100) {
	                        existingEquipment.setQuantity(newQuantity);
	                        System.out.println("Quantity updated successfully!");
	                    } else {
	                        System.out.println("Invalid input. Quantity must be between 1 and 100. Please try again.");
	                    }
	                } catch(NumberFormatException e) {
	                    System.out.println("Invalid input. Please enter a number.");
	                }
	            }
	            
	            String newEquipDescription =  validateInput(scanner, "\nNew Equipment Description: ", "Invalid description. Please enter a valid name.", "^[a-zA-Z ]+$");
	            if(!newEquipDescription.isBlank()) {
	                existingEquipment.setEquipDescription(newEquipDescription);
	                System.out.println("Equipment description updated successfully!");
	            }

	            gymManagementSystem.saveData(); // Save data after updating equipment
	            System.out.println("\nEquipment updated successfully.");
	            return; // Return after updating the equipment information
	        }
	    }
	    System.out.println("\nError: Equipment with Name: "+equipName+" not found.\n");
	}
	//Method to delete Equipment
	private void deleteEquipment() {
	    System.out.print("Enter the name of the equipment to delete: ");
	    String equipName = scanner.nextLine();
	    boolean isDeleted = gymManagementSystem.deleteEquipmentByName(equipName);
	    if (isDeleted) {
	        System.out.println("\nEquipment deleted successfully.");
	        gymManagementSystem.saveData();
	    } else {
	        System.out.println("\nEquipment not found.");
	    }
	}
	// Method to search a class
	private void searchClass() {
	    System.out.print("Enter keyword to search Example(classID or className or instructorName or Capacity): ");
	    String keyword = scanner.nextLine();

	    // If the keyword is blank, return
	    if(keyword.isBlank()) {
	        System.out.println("\nNo keyword entered. Please try again with a valid keyword.");
	        return;
	    }

	    List<FitnessClass> foundClasses = gymManagementSystem.searchClasses(keyword);

	    if (foundClasses.isEmpty()) {
	        System.out.println("\nNo classes found with the keyword: " + keyword);
	    } else {
	        System.out.println("\n***********Schedules Classes found:***************");
	        for (FitnessClass fitnessClass : foundClasses) {
	            System.out.println("Class ID: " + fitnessClass.getRoomID() + ", Room Name: " + fitnessClass.getRoomName() + ", Instructor Name: " + fitnessClass.getInstructorName() + ", Start Time: " + fitnessClass.getStartTime() + ", End Time: " + fitnessClass.getEndTime() + ", Capacity: " + fitnessClass.getCapacity());
	        }
	    }
	}

	// Method to search Equipment 
		private void searchEquipment() {
		    System.out.print("Enter keyword to search Example(Equipmnet_name or equipment descrisption): ");
		    String keyword = scanner.nextLine();
		 // If the keyword is blank, return
		    if(keyword.isBlank()) {
		        System.out.println("\nNo keyword entered. Please try again with a valid keyword.");
		        return;
		    }
		    List<Equipment> foundClasses = gymManagementSystem.searchEquipment(keyword);

		    if (foundClasses.isEmpty()) {
		        System.out.println("\nNo Equipment found with the keyword: " + keyword);
		    } else {
		        System.out.println("\n***********Schedules Classes found:***************");
		        for (Equipment equipment : foundClasses) {
		            System.out.println("Equipment Name: " + equipment.getEquipName() + ", Quantity: " + equipment.getQuantity() + ", Description: " + equipment.getEquipDescription());
		        }
		    }
		}

	//Method to Cancel Exiting class
	private void cancelClass() {
		System.out.print("Enter Class ID to cancel: ");
		String classId = scanner.nextLine();

		try {
			gymManagementSystem.cancelClass(classId);
			gymManagementSystem.saveData(); // Save data after cancelling a class
			System.out.println("\nClass cancelled successfully.");
		} catch (InvalidClassException e) {
			System.out.println("\nError cancelling class: " + e.getMessage());
		}
	}
	//Method to update Member Information 
	private void updateMemberInformation() throws InvalidUserException{
	    System.out.print("Enter Member ID: ");
	    String memberId = scanner.nextLine();
	    
	    // Find the member with the given ID
	    for(Member member : gymManagementSystem.getMembers()) {
	        if(member.getMemberId().equals(memberId)) {
	            // Display current details
	            System.out.println("\nCurrent Details - Name: " + member.getName() + ", Type: " + member.getMembershipType() + ", Contact: " + member.getContactNumber() + ", Email: " + member.getEmail());
	            
	            while(true) {
	                try {
	                    System.out.print("\nNew Contact Number (press enter to skip): ");
	                    String newContactNumber = scanner.nextLine();
	                    if(!newContactNumber.isBlank()) {
	                        member.setContactNumber(newContactNumber);
	                        System.out.println("Contact number updated successfully!");
	                    }
	                    break;
	                } catch(InvalidUserException e) {
	                    System.out.println("Invalid contact number. Example: 6142970336, Please try again.");
	                }
	            }
	         // Update email
	            while(true) {
	                try {
	                    System.out.print("\nNew Email (press enter to skip): ");
	                    String newEmail = scanner.nextLine();
	                    if(!newEmail.isBlank()) {
	                        member.setEmail(newEmail);
	                        System.out.println("Email updated successfully!");
	                    }
	                    break;
	                } catch(InvalidUserException e) {
	                    System.out.println("Invalid email format. Email must match the pattern '^[A-Za-z0-9+_.-]+@(.+)$'. Example: test@gmail.com.");
	                }
	            }
	            // Update membership type
	            while(true) {
	            	try {
	            		System.out.print("\nNew Membership Type (press enter to skip): \n");
	    	            String newMembershipType = scanner.nextLine();
	    	            if(!newMembershipType.isBlank()) {
	    	            	if(newMembershipType.equalsIgnoreCase("Standard") || newMembershipType.equalsIgnoreCase("Premium")) {
	    	            		member.setMembershipType(newMembershipType);
	    	            		gymManagementSystem.saveData(); // Save data after updating member information
	    	            		System.out.println("Membership type updated successfully!\n");
	    	            	}else {
	    	            		throw new InvalidUserException("Invalid membership type. Please enter either 'Standard' or 'Premium'.");
	    	            	}
	    	            }
	    	            System.out.println("\nMember details updated successfully!\n");
	    	            break;
	            	}catch(InvalidUserException e) {
	            		System.out.println(e.getMessage());
	            	}
	            }
	            return; // Return after updating the member information
	        }
	    }
	    System.out.println("\nError: Member with Id: "+memberId+" not found.\n");
	}
	
	// Method to update Staff Information 
	private void updateStaffInformation() throws InvalidUserException { 
	    System.out.print("Enter Staff ID: ");
	    String staffId = scanner.nextLine();

	    // Find the staff with the given ID
	    boolean staffFound = false;
	    for (Staff staff : gymManagementSystem.getStaffs()) {
	        if (staff.getStaffId().equals(staffId)) {
	            staffFound = true;

	            // Display current details
	            System.out.println("\nCurrent Details - Name: " + staff.getName() + ", Contact: " + staff.getContactNumber() + ", Role: " + staff.getRole() + ", Email: " + staff.getEmail());

	            // Update contact number
	            while (true) {
	                try {
	                    System.out.print("\nNew Contact Number (press enter to skip): ");
	                    String newContactNumber = scanner.nextLine();
	                    if (!newContactNumber.isBlank()) {
	                        staff.setContactNumber(newContactNumber);
	                        System.out.println("Contact number updated successfully!");
	                    }
	                    break;
	                } catch (InvalidUserException e) {
	                    System.out.println("Invalid contact number. Example: 6142970336, Please try again.");
	                }
	            }

	            // Update email
	            while (true) {
	                try {
	                    System.out.print("\nNew Email (press enter to skip): ");
	                    String newEmail = scanner.nextLine();
	                    if (!newEmail.isBlank()) {
	                        staff.setEmail(newEmail);
	                        System.out.println("Email updated successfully!");
	                    }
	                    break;
	                } catch (InvalidUserException e) {
	                    System.out.println("Invalid email format. Email must match the pattern '^[A-Za-z0-9+_.-]+@(.+)$'. Example: test@gmail.com");
	                }
	            }

	         // Update role
	            while (true) {
	                System.out.print("\nNew Role (press enter to skip): ");
	                String newRole = scanner.nextLine();
	                if (newRole.isBlank()) {
	                    break;
	                } else if (newRole.matches("^[a-zA-Z ]+$")) {
	                    staff.setRole(newRole);
	                    System.out.println("Role updated successfully!");
	                    System.out.println("\nStaff details updated successfully!\n");
	                    break;
	                } else {
	                    System.out.println("Invalid role. Please enter a valid role.");
	                }
	            }

	            gymManagementSystem.saveData(); // Save data after updating Staff information
	            System.out.println("\nStaff information updated successfully!\n");
	            return; // Return after updating the staff information
	        }
	    }

	    if (!staffFound) {
	        System.out.println("\nError: Staff with ID: " + staffId + " not found.\n");
	    }
	}
	
	// Method to validate user input
	public static String validateInput(Scanner scan, String prompt, String errorMessage, String checkRegres) {
		System.out.print(prompt); 
		String input = scan.nextLine();
		
		while(!input.matches(checkRegres)) {
			System.out.println(errorMessage);
			System.out.print(prompt);
			input = scan.nextLine();
		}
		return input;
	}
}
