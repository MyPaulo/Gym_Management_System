// User is an abstract class that serves as a base class for other classes in our gym management system.
// It implements the Serializable interface to allow User objects to be converted to a byte stream,
// which is useful for saving objects to disk or sending them over a network.
// Each User object represents a unique user in the system and has an ID, a name, a contact number, and an email address

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.Serializable;

abstract class User implements Serializable { 
	
	private static final long serialVersionUID = 1L; // Unique ID for serialization and deserialization of the User class
	// Regular expression for email validation
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@(.+)$";
	
	
	protected String id; // Unique identifier for the user
	protected String name;    // Name of the user
	protected String contactNumber; // Contact number of the user
	protected String email; // User Email
	
	// Default constructor that initializes the id and name fields with empty strings
	public User() {
		this.id = "";
		this.name = "";
	}
	// Parameterized constructor that initializes the id and name fields with the provided values
	public User(String id,String name) {
		this.id = id;
		this.name = name;
	}
	//Getters and Setters for retrieving and updating User details 
	public String getId() {
		return this.id;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return this.contactNumber;
	}
	// Setter for contact number with validation
	public void setContactNumber(String contactNumber) throws InvalidUserException{
		 if(!isValidPhoneNumber(contactNumber)) {
			 throw new InvalidUserException("Invalid phone number format. phone number must be 10 digits Example: 1234567890");
		 }
		 this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return this.email;
	}
	// Setter for email with validation
	// Throws InvalidUserException if the provided contact details are invalid
	public void setEmail(String email) throws InvalidUserException {
		if(!isValidEmail(email)) {
			throw new InvalidUserException("Invalid email format. Email must match the pattern '^[A-Za-z0-9+_.-]+@(.+)$'. Example: test@gmail.com");
	       }
	       this.email = email;
	}
	 
	//static method to validate phone number (must be 10 digits)
	 static boolean isValidPhoneNumber(String phoneNumber) {
		return phoneNumber.matches("\\d{10}");
	}
	// static method to validate email (must contain "@")
	 static boolean isValidEmail(String email) {
		 Pattern pattern = Pattern.compile(EMAIL_REGEX);
	        Matcher matcher = pattern.matcher(email);
	        return matcher.matches();
		//return email.contains("@") && email.contains(".");
	}

	// Method to update contact details with validation
	// Throws InvalidUserException if the provided contact details are invalid.
    public void updateContactDetails(String contactNumber, String memberEmail) throws InvalidUserException{
    	 setContactNumber(contactNumber);
         setEmail(memberEmail);
    }
    
    //Overridden method to get basic user information.
	public String getUserInfo() {
		return "ID: " +id + ", Name: " + name;
	}
}