
import java.io.Serializable;

//Member is a class that represents a member in our gym management system.
//It extends the User superclass inheriting it properties, methods  and implements the Serializable interface
class Member extends User implements Serializable{
    // A static variable to generate unique IDs for each member.
    private static int uniqueID = 0;
    private static final long serialVersionUID = 1L;// Unique ID for serialization and deserialization of the Member class
    // Represents the type of membership the member has (e.g., Standard, Premium).
    private String membershipType;

    // Default constructor that initializes with default values and generates a unique ID.
    public Member() {
        super("MEM" + String.format("%04d", getNextUniqueId()), "Member-class");
        this.membershipType = " ";
    }

    // Parameterized constructor that initializes with provided values and generates a unique ID.
    // Throws InvalidUserException if the provided user details are invalid.
    public Member(String name, String membershipType, String contactNumber, String memberEmail) throws InvalidUserException {
        super("MEM" + String.format("%04d", getNextUniqueId()), name);
        this.membershipType = membershipType;
        setContactNumber(contactNumber);
        setEmail(memberEmail);
    }
    // Getters and setters for the retrieving and updating member's details
	 public String getMemberId() {
		 return super.getId();
	 }
	 public String getName() {
		 return super.getName();
	 }
	 public void setName(String name) {
		 super.setName(name);
	 }
	 public String getMembershipType() {
		 return this.membershipType;
	 }
	 public void setMembershipType(String membershipType) {
		 this.membershipType = membershipType;
	 }
	 public String getContactNumber() {
		 return this.contactNumber;
	 }
	 
	// Synchronized method to ensure thread safety when generating unique IDs
	 public synchronized static int getNextUniqueId() {
		 return uniqueID++;
	 }
	 public static synchronized void setUniqueID(int uniqueID) {
		    Member.uniqueID = uniqueID; 
		}
	// Overridden method to get detailed member information
	   @Override
	 public String getUserInfo() {
		   return  getId() + ", Name: " + getName() +
	               ", Membership Type: " + membershipType +
	               ", Contact Number: " + getContactNumber() +
	               ", Email: " + getEmail();
	 }
	// Overridden toString method to return detailed member information
	@Override
	public String toString() {
		return getUserInfo();
	}
}